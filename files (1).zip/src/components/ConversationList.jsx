import React, { useState } from 'react';
import '../styles/ConversationList.css';

function ConversationList({ conversations, onSelectUser, onlineUsers, selectedUser }) {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = async (query) => {
    setSearchQuery(query);
    if (query.length > 2) {
      try {
        const response = await fetch(
          `http://localhost:5000/api/users/search/${query}`,
          {
            headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
          }
        );
        const users = await response.json();
        // Handle search results
      } catch (error) {
        console.error('Search error:', error);
      }
    }
  };

  return (
    <div className="conversation-list">
      <div className="list-header">
        <h1>WebChats</h1>
        <input
          type="text"
          placeholder="Search contacts..."
          value={searchQuery}
          onChange={(e) => handleSearch(e.target.value)}
        />
      </div>

      <div className="conversations">
        {conversations.map((conv, index) => (
          <div
            key={index}
            className={`conversation-item ${selectedUser?._id === conv._id ? 'active' : ''}`}
            onClick={() => onSelectUser(conv)}
          >
            <div className="conv-info">
              <h3>{conv.firstName} {conv.lastName}</h3>
              <p className="last-message">{conv.lastMessage}</p>
            </div>
            <span className="time">
              {new Date(conv.lastMessageTime).toLocaleTimeString()}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ConversationList;