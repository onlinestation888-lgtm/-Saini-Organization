import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Auth from './pages/Auth';
import Chat from './pages/Chat';
import Profile from './pages/Profile';
import Header from './components/Header';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(!!localStorage.getItem('token'));

  return (
    <Router>
      <div className="app">
        {isAuthenticated && <Header />}
        <Routes>
          {!isAuthenticated ? (
            <Route path="/*" element={<Auth setIsAuthenticated={setIsAuthenticated} />} />
          ) : (
            <>
              <Route path="/" element={<Chat />} />
              <Route path="/profile" element={<Profile />} />
            </>
          )}
        </Routes>
      </div>
    </Router>
  );
}

export default App;