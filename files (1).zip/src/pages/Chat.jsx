import React, { useState, useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import ConversationList from '../components/ConversationList';
import ChatWindow from '../components/ChatWindow';
import '../styles/Chat.css';

function Chat() {
  const [socket, setSocket] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [onlineUsers, setOnlineUsers] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));
  const token = localStorage.getItem('token');

  useEffect(() => {
    const newSocket = io('http://localhost:5000', {
      auth: { token }
    });

    newSocket.on('connect', () => {
      newSocket.emit('user-online', user.id);
    });

    newSocket.on('online-users', (users) => {
      setOnlineUsers(users);
    });

    newSocket.on('receive-message', (message) => {
      if (selectedUser && (message.sender === selectedUser.id || message.recipient === selectedUser.id)) {
        setMessages(prev => [...prev, message]);
      }
    });

    setSocket(newSocket);

    return () => newSocket.disconnect();
  }, [user.id, token, selectedUser]);

  useEffect(() => {
    fetchConversations();
  }, []);

  const fetchConversations = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/chat/conversations', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      setConversations(data);
    } catch (error) {
      console.error('Error fetching conversations:', error);
    }
  };

  const handleSelectUser = async (selectedUser) => {
    setSelectedUser(selectedUser);
    try {
      const response = await fetch(`http://localhost:5000/api/chat/history/${selectedUser.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      setMessages(data);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const handleSendMessage = (messageContent) => {
    if (socket && selectedUser) {
      const messageData = {
        from: user.id,
        to: selectedUser.id,
        message: messageContent,
        timestamp: new Date()
      };
      socket.emit('send-message', messageData);
      setMessages(prev => [...prev, { ...messageData, sender: user.id, recipient: selectedUser.id, content: messageContent }]);
    }
  };

  return (
    <div className="chat-container">
      <ConversationList
        conversations={conversations}
        onSelectUser={handleSelectUser}
        onlineUsers={onlineUsers}
        selectedUser={selectedUser}
      />
      {selectedUser ? (
        <ChatWindow
          selectedUser={selectedUser}
          messages={messages}
          onSendMessage={handleSendMessage}
          currentUser={user}
        />
      ) : (
        <div className="no-chat-selected">
          <p>Select a conversation to start chatting</p>
        </div>
      )}
    </div>
  );
}

export default Chat;