# 🚀 WebChats - Real-Time Messenger App

A modern, feature-rich messenger application built with React, Node.js, and Socket.IO. Users can register using their phone number and email, then instantly start messaging.

## ✨ Features

- 📱 **Phone Number Authentication** - Register and login using phone number
- 📧 **Email Verification** - OTP-based email verification
- 💬 **Real-Time Messaging** - Socket.IO powered instant messaging
- 👥 **User Search** - Find and message any registered user
- 🟢 **Online Status** - See who's online in real-time
- 📱 **Responsive Design** - Works on desktop and mobile devices
- 🎨 **Modern UI** - Clean and intuitive user interface

## 🛠️ Tech Stack

### Frontend
- React 18
- Vite
- Socket.IO Client
- Tailwind CSS

### Backend
- Node.js
- Express.js
- MongoDB
- Socket.IO
- JWT Authentication

## 📋 Prerequisites

- Node.js 14+
- MongoDB
- npm or yarn

## 🚀 Installation

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/webchats.git
cd webchats
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Setup Environment Variables
```bash
cp .env.example .env
```

Edit `.env` with your configuration:
- MongoDB connection string
- JWT secret key
- Twilio credentials (optional, for SMS)

### 4. Start MongoDB
```bash
mongod
```

### 5. Run Development Servers
```bash
npm run dev
```

This will start:
- Backend: http://localhost:5000
- Frontend: http://localhost:5173

## 📖 Usage

1. **Register**: Create an account with phone number, email, and password
2. **Verify**: Confirm your email with OTP
3. **Login**: Sign in with phone number and password
4. **Chat**: Search for contacts and start messaging instantly

## 📁 Project Structure

```
webchats/
├── server/
│   ├── models/
│   │   ├── User.js
│   │   └── Message.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── chat.js
│   │   └── users.js
│   ├── middleware/
│   │   └── auth.js
│   └── index.js
├── src/
│   ├── pages/
│   │   ├── Auth.jsx
│   │   ├── Chat.jsx
│   │   └── Profile.jsx
│   ├── components/
│   │   ├── ChatWindow.jsx
│   │   ├── ConversationList.jsx
│   │   └── Header.jsx
│   ├── styles/
│   │   ├── Auth.css
│   │   ├── Chat.css
│   │   └── ChatWindow.css
│   └── App.jsx
├── .env
├── .env.example
├── package.json
└── README.md
```

## 🔐 Security Features

- Password hashing with bcryptjs
- JWT token-based authentication
- Email verification with OTP
- Input validation with validator.js
- CORS protection

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

Created with ❤️ by WebChats Team

## 📞 Support

For support, open an issue on GitHub or contact us at support@webchats.app

---

**WebChats** - Chat Anywhere, Anytime! 🌍💬